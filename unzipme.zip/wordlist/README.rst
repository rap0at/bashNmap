
References for Wordlists used in Jok3r:

* Metasploit
* https://github.com/govolution/betterdefaultpasslist
* https://github.com/1N3/BruteX
* https://github.com/berzerk0/Probable-Wordlists
* https://github.com/danielmiessler/SecLists
* https://github.com/tarraschk/richelieu
