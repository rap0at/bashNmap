# Import modules
import os

# Clear command line
if os.name == "nt":
    os.system("@cls & @title Impulse ToolKit & @color e")
else:
    os.system("clear")
